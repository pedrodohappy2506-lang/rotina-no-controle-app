import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const html = await readFile('www/index.html');
console.log(`HTML preservado. SHA-256: ${createHash('sha256').update(html).digest('hex')}`);
if (!html.length) throw new Error('www/index.html está vazio');
