import { readFile, writeFile } from 'node:fs/promises';

try {
  const path = 'android/app/src/main/AndroidManifest.xml';
  let s = await readFile(path, 'utf8');
  if (!s.includes('android.permission.CAMERA')) {
    s = s.replace('</manifest>', '    <uses-permission android:name="android.permission.CAMERA" />\n</manifest>');
    await writeFile(path, s);
  }
} catch (e) { console.warn('Android: permissão de câmera não aplicada:', e.message); }

try {
  const path = 'ios/App/App/Info.plist';
  let s = await readFile(path, 'utf8');
  if (!s.includes('NSCameraUsageDescription')) {
    s = s.replace('</dict>', '  <key>NSCameraUsageDescription</key>\n  <string>O Rotina no Controle usa a câmera para escanear ingredientes alimentares.</string>\n</dict>');
    await writeFile(path, s);
  }
} catch (e) { console.warn('iOS: descrição de câmera não aplicada:', e.message); }
