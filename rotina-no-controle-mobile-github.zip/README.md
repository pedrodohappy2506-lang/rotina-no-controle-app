# Rotina no Controle — Mobile

Empacotamento do **HTML original** como app Android/iOS usando Capacitor.

## Preservação
`www/index.html` é uma cópia integral do arquivo enviado. Nenhum botão, tela, texto, função ou layout foi alterado. Foram adicionados somente arquivos externos para empacotamento/instalação.

## GitHub Pages
O workflow **Deploy PWA** publica `www/` no GitHub Pages. Android pode instalar pelo Chrome; iPhone pelo Safari em **Compartilhar → Adicionar à Tela de Início**.

## Android
O workflow **Build Android** gera `app-debug.apk` como artefato. É um APK instalável para testes.

## iOS
O workflow **Build iOS** usa macOS, cria o projeto Xcode e publica `ios-project.zip` e um build para simulador. Para iPhone físico/TestFlight/App Store é necessária assinatura Apple.

## Local
```bash
npm install
npx cap add android
npx cap add ios
npm run prepare:native
npx cap sync
```
Depois:
```bash
npx cap open android
npx cap open ios
```

## Identidade
- Nome: Rotina no Controle
- ID: `br.com.rotinacontrole.app`

## Gemini
A chave da Gemini já está dentro do HTML original. Para respeitar o pedido, ela não foi removida nem o HTML foi reescrito. Uma chave no frontend pode ser extraída de um APK/IPA ou da página web. Para uma versão comercial, o ideal é mover a chave para o backend e usar um endpoint seguro.
