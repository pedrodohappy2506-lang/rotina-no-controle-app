import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.com.rotinacontrole.app',
  appName: 'Rotina no Controle',
  webDir: 'www',
  android: { backgroundColor: '#080b13' },
  ios: { contentInset: 'automatic' }
};

export default config;
